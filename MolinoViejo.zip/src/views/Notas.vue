<template>
  <div class="swiper-container">
    <!-- Additional required wrapper -->
    <div class="swiper-wrapper">
      <div class="swiper-slide" id="slide-0">
         <b-container fluid class="p-0 m-0 p-conten bg-1  vh-100 bv-example-row">
    <b-row align-h="center" class="p-5">
      <b-col xl="4" lg="4" sm="12" cols="12" class="text-center">
        <img
          id="img1"
          src="recursos/img/Movilidad-M1-001.png"
          alt=""
          class="img-fluid animate__animated animate__fadeIn"
        />
      </b-col>
    </b-row>
    <b-row align-h="center" class="p-0 m-0">
      <b-col xl="9" lg="9" sm="12" cols="12">
        <h2 class="text-left text-white animate__animated animate__bounceInLeft animate__delay-1s m-0 p-0">Curso pedagógico de</h2>
        <h3 class="text-right col_t1 animate__animated animate__bounceInRight animate__delay-2s m-0  p-0">educación vial para amonestados</h3>
      </b-col>
    </b-row>
    <b-row align-h="center" class="text-center">
      <b-col lg="6" cols="12" class="pt-5  mb-0">
        <div>
          <img
          src="recursos/img/Logo-alcaldia.png"
          id="logoAlc1"
          class="img-fluid animate__animated animate__bounceInUp animate__delay-3s  w-50 "
          alt=""
        />
        </div>
        
      </b-col>
    </b-row>
  
  </b-container>
      </div>
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-1">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row>
            <b-col xl="6" md="12" col class="mt-lg-5">
              <div class="position-relative">
                <div class="text-left">
                  <img
                    src="recursos/img/Fondo01.png"
                    alt=""
                    class="img-fluid animate__animated animate__fadeIn position-absolute pt-lg-5 mt-lg-5"
                  />
                </div>

                <div class="p-5 my-5 my-lg-3">
                  <img
                    src="recursos/img/Agente_transito.png"
                    alt=""
                    class="img-fluid agenteM11 animate__animated animate__bounceInLeft animate__delay-1s w-50 position-absolute p-4 p-lg-5"
                  />
                </div>
              </div>
            </b-col>
            <b-col xl="6" md="12" cols="12">
              <div
                class="p-4 animate__animated animate__bounceInRight animate__delay-2s mt-5 position-relative"
              >
                <h2 class="col_t1 pt-5 pt-lg-0">
                  Módulo 1. <br />
                  Factores de riesgo y seguridad vial
                </h2>
                <p>
                  En este módulo conocerás aspectos relacionados con los
                  factores de riesgo que aumentan la posibilidad de incidentes.
                   Igualmente, se abordará aquellos comportamientos
                  ciudadanos que afectan la seguridad vial y que pone en riesgo
                  a los demás actores viales.
                </p>
                <p>
                  Colombia, acatando el llamado para la disminución de cifras de
                  lesionados y muertos por causa de incidentes de tránsito, ha
                  abordado la Seguridad Vial como una política de Estado, en
                  virtud del cual se generan acciones que buscan garantizar el
                  derecho a la movilidad segura.
                </p>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-2">
        <b-container class="bv-example-row bv-example-row-flex-cols">
          <b-row align-content="center margen_principal">
            <b-col xl="12" lg="12" md="12" col align-self="center">
              <div class="">
                <h3 class="col_t1">Compromisos en seguridad vial</h3>
                <h4 class="mt-5 col_t1">Compromisos a nivel mundial</h4>
                <figure>
                  <img
                    src="recursos/img/Movilidad-M1_005_img01.png"
                    class="img-fluid d-none d-md-block"
                    alt=""
                  />
                  <img
                    src="recursos/img/Movilidad-M1_005_img01_cel.png"
                    class="img-fluid d-block d-md-none"
                    alt=""
                  />
                </figure>
                <h4 class="mt-5 col_t1">Compromisos a nivel nacional</h4>
                <figure>
                  <img
                    src="recursos/img/Movilidad-M1_005_img02.png"
                    class="img-fluid d-none d-md-block"
                    alt=""
                  />
                  <img
                    src="recursos/img/Movilidad-M1_005_img02_cel.png"
                    class="img-fluid d-block d-md-none"
                    alt=""
                  />
                </figure>
                <h4 class="mt-5 col_t1">
                  Compromisos del Plan Decenal de Salud Pública
                </h4>
                <figure>
                  <img
                    src="recursos/img/Movilidad-M1_005_img03.png"
                    class="img-fluid d-none d-md-block"
                    alt=""
                  />
                  <img
                    src="recursos/img/Movilidad-M1_005_img03_cel.png"
                    class="img-fluid d-block d-md-none"
                    alt=""
                  />
                </figure>
                <p>Fuente: Ministerio de Salud. Recuperado de: <a target="_blank" class="linkVerde" href="https://www.minsalud.gov.co/sites/rid/Lists/BibliotecaDigital/RIDE/VS/PP/SA/cartilla-movilidad-sss.pdf"> https://www.minsalud.gov.co/sites/rid/Lists/BibliotecaDigital/RIDE/VS/PP/SA/cartilla-movilidad-sss.pdf.</a></p>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>
       
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-3">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row align-v="center">
            <b-col
              xl="5"
              md="12"
              cols="12"
              class="Fondo-Cifras d-lg-block d-none"
            >
              <span class="ref1"
                >Photochur (2015) Accidente de tránsito. Recuperado de
                <a
                  href="https://pixabay.com/es/photos/accidente-de-transito-accidente-2746667/"
                  target="_blank"
                >
                  https://pixabay.com/es/photos/accidente-de-transito-accidente-2746667/
                </a>
              </span>
            </b-col>
            <b-col xl="7" md="12" cols="12">
              <b-row align-h="center">
                <b-col xl="11" cols="12">
                  <div class="px-4 py-2 sombra1 rounded mb-4">
                    <b-row class="border1 rounded justify-content-center p-3">
                      <b-col
                        lg="4"
                        md="4"
                        sm="4"
                        cols="12"
                        class="text-center mb-5"
                      >
                        <img
                          src="recursos/img/Para_no_olvidar.png"
                          alt=""
                          class="img-fluid"
                        />
                      </b-col>
                      <b-col lg="8" md="8" sm="8" cols="12">
                        <h5 class="col_t1">Para no olvidar:</h5>
                        <p>
                          Toda muerte por un accidente vial se puede prevenir.
                        </p>
                      </b-col>
                    </b-row>
                  </div>

                  <h3 class="col_t1">Cifras de accidentalidad</h3>
                  <p>
                    El Plan Mundial para el Decenio de Acción para la Seguridad
                    Vial 2011–2020 promovido por la Organización de las Naciones
                    Unidas (ONU), afirma que:
                  </p>
                  <p class="ml-5 borderLeft px-5 py-3 sombra1 rounded">
                    Cada año, cerca de 1,3 millones de personas fallecen a raíz
                    de un accidente de tránsito —más de 3 000 defunciones
                    diarias— y más de la mitad de ellas no viajaban en
                    automóvil. Entre 20 millones y 50 millones de personas más
                    sufren traumatismos no mortales provocados por accidentes de
                    tránsito, y tales traumatismos constituyen una causa
                    importante de discapacidad en todo el mundo. (2011, p. 4).
                  </p>
                  <p>
                    Es importante advertir que, los traumatismos por accidentes
                    de tránsito son un problema de salud pública en el mundo.
                    Frente a esta problemática, el 93% de las muertes por
                    accidente de tránsito se producen en países de ingresos
                    bajos y medianos, que solo cuentan con el 54% de los
                    vehículos matriculados en el mundo. (Organización Mundial de
                    la Salud. 2017)
                  </p>
                  <p>
                    En el contexto colombiano, las altas cifras de
                    accidentalidad y la tendencia presentada en los últimos
                    siete años, que corresponde al periodo 2012 - 2019, muestran
                    una cifra de 1.839.913 accidentes viales, cobrando la vida
                    de 57.239 personas y dejando lesionadas a 344.721 personas.
                  </p>
                </b-col>
              </b-row>
            </b-col>
          </b-row>
        </b-container>
      </div>

      
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-4">
        <b-container class="bv-example-row bv-example-row-flex-cols">
          <b-row class="margen_principal justify-content-center">
            <b-col xl="8" lg="8" md="12" col align-self="center">
              <div class="text-center">
                <div>
                  <b-table-simple hover striped responsive class="rounded-lg">
                    <b-thead class="thead1">
                      <b-tr>
                        <b-th>Año ocurrencia</b-th>
                        <b-th>Lesionados en accidentes viales Colombia</b-th>
                        <b-th>Muertes en accidentes viales Colombia</b-th>
                        <b-th>Muertes en accidentes viales Medellín</b-th>
                        <b-th>Lesionados en Medellín</b-th>
                      </b-tr>
                    </b-thead>
                    <b-tbody>
                      <b-tr>
                        <b-td>2019</b-td>
                        <b-td>36.812</b-td>
                        <b-td>6.826</b-td>
                        <b-td>250</b-td>
                        <b-td>2.584</b-td>
                      </b-tr>
                      <b-tr>
                        <b-td>2018</b-td>
                        <b-td>39.517</b-td>
                        <b-td>6.850</b-td>
                        <b-td>239</b-td>
                        <b-td>2.551</b-td>
                      </b-tr>
                      <b-tr>
                        <b-td>2017</b-td>
                        <b-td>40.088</b-td>
                        <b-td>6.719</b-td>
                        <b-td>265</b-td>
                        <b-td>2.294</b-td>
                      </b-tr>
                      <b-tr>
                        <b-td>2016</b-td>
                        <b-td>45.230</b-td>
                        <b-td>7.158</b-td>
                        <b-td>272</b-td>
                        <b-td>2.724</b-td>
                      </b-tr>
                      <b-tr>
                        <b-td>2015</b-td>
                        <b-td>45.778</b-td>
                        <b-td>6.831</b-td>
                        <b-td>277</b-td>
                        <b-td>2.909</b-td>
                      </b-tr>
                      <b-tr>
                        <b-td>2014</b-td>
                        <b-td>44.452</b-td>
                        <b-td>6.352</b-td>
                        <b-td>290</b-td>
                        <b-td>2.676</b-td>
                      </b-tr>
                      <b-tr>
                        <b-td>2013</b-td>
                        <b-td>41.797</b-td>
                        <b-td>6.211</b-td>
                        <b-td>306</b-td>
                        <b-td>2.930</b-td>
                      </b-tr>
                      <b-tr>
                        <b-td>2012</b-td>
                        <b-td>39.427</b-td>
                        <b-td>6.136</b-td>
                        <b-td>278</b-td>
                        <b-td>2.699</b-td>
                      </b-tr>
                    </b-tbody>
                    <b-tfoot class="thead1">
                      <b-tr class="rounded-bottom">
                        <b-td> <b>Total</b> </b-td>
                        <b-td> <b>333.101</b> </b-td>
                        <b-td> <b>53.083</b> </b-td>
                        <b-td> <b>2.177</b> </b-td>
                        <b-td> <b>21.367</b> </b-td>
                      </b-tr>
                    </b-tfoot>
                  </b-table-simple>
                  <br />
                  <p class="text-left">
                    Fuente: Datos procesados por el Observatorio Nacional de
                    Seguridad Vial-ONSV con base en información del Instituto
                    Nacional de Medicina Legal y Ciencias Forenses-INMLCF.
                    Noviembre, 2020.
                  </p>
                </div>
              </div>
            </b-col>

            <b-col xl="12" lg="12" md="12" col class="text-center">
              <figure class="figure">
                <img
                  src="recursos/img/Movilidad_M1_008_img02.png"
                  class="img-fluid d-none d-md-block"
                  alt=""
                  srcset=""
                />
                <img
                  src="recursos/img/Movilidad_M1_008_img02_cel.png"
                  class="img-fluid d-block d-md-none"
                  alt=""
                  srcset=""
                />
                <figcaption class="mt-3 text-left">
                  Fuente: Ministerio de Salud. Recuperado de:
                  <b-link
                    href="https://www.minsalud.gov.co/sites/rid/Lists/BibliotecaDigital/RIDE/VS/PP/SA/cartilla-movilidad-sss.pdf"
                    >https://www.minsalud.gov.co/sites/rid/Lists/BibliotecaDigital/RIDE/VS/PP/SA/cartilla-movilidad-sss.pdf</b-link
                  >
                </figcaption>
              </figure>
            </b-col>
          </b-row>
        </b-container>
      </div>
      
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-5"
      >
        <b-container fluid="" class="bv-example-row bv-example-row-flex-cols">
          <b-row class="margen_principal justify-content-center">
            <b-col xl="10" lg="10" md="12" col align-self="center">
              <div class="text-center">
                <div>
                  <h4 class="col_t1">¿Cómo estamos en Medellín…?</h4>
                  <br />
                  <b-row class="">
                    <b-col
                      class="p-1 animado m-0 animado-Arr animate__bounceInUp animate__delay-1s"
                      md="6"
                      sm="12"
                      cols="12"
                    >
                      <div class="p-2 senalInfo1">
                        <div class="p-3 senalInfo2">
                          <span
                            >En Medellín se presenta un choque cada 5
                            minutos</span
                          >
                          <img src="recursos/img/arrow.svg" alt="Arrow right" />
                        </div>
                      </div>
                    </b-col>
                    <b-col
                      class="p-1 animado m-0 animado-Ab animate__bounceInDown animate__delay-1s"
                      md="6"
                      sm="12"
                      cols="12"
                    >
                      <div class="p-2 senalInfo1">
                        <div class="p-3 senalInfo2">
                          <span
                            >Cada 35 horas fallece una persona por incidente de
                            tránsito en Medellín</span
                          >
                          <img
                            src="recursos/img/arrow.svg"
                            alt="Arrow right"
                            class="rotacion90°"
                          />
                        </div>
                      </div>
                    </b-col>
                    <b-col
                      class="p-1 animado m-0 animado-Iz animate__bounceInDown animate__delay-2s"
                      md="6"
                      sm="12"
                      cols="12"
                    >
                      <div class="p-2 senalInfo1">
                        <div class="p-3 senalInfo2">
                          <img
                            src="recursos/img/arrow.svg"
                            alt="Arrow right"
                            class="mr-3 rotacion90°"
                          />
                          <span
                            >Cada 16 minutos resulta lesionada una persona por
                            accidente de transito en Medellín</span
                          >
                        </div>
                      </div>
                    </b-col>
                    <b-col
                      class="p-1 animado m-0 animado-Der animate__bounceInLeft animate__delay-2s"
                      md="6"
                      sm="12"
                      cols="12"
                    >
                      <div class="p-2 senalInfo1">
                        <div class="p-3 senalInfo2">
                          <img
                            src="recursos/img/arrow.svg"
                            alt="Arrow right"
                            class="mr-3 rotacion180°"
                          />
                          <span>De cada 10 muertos, 7 son peatones</span>
                        </div>
                      </div>
                    </b-col>
                    <b-col
                      class="p-1 animado m-0 animado-Arr animate__bounceInRight animate__delay-3s"
                      md="6"
                      sm="12"
                      cols="12"
                    >
                      <div class="p-2 senalInfo1">
                        <div class="p-3 senalInfo2">
                          <span
                            >El 95% de los muertos en incidentes viales son
                            hombres</span
                          >
                          <img src="recursos/img/arrow.svg" alt="Arrow right" />
                        </div>
                      </div>
                    </b-col>
                    <b-col
                      class="p-1 animado m-0 animado-Ab animate__bounceInDown animate__delay-3s"
                      md="6"
                      sm="12"
                      cols="12"
                    >
                      <div class="p-2 senalInfo1">
                        <div class="p-3 senalInfo2">
                          <span
                            >En Medellín se presenta un choque cada 5
                            minutos</span
                          >
                          <img
                            src="recursos/img/arrow.svg"
                            alt="Arrow right"
                            class="rotacion90°"
                          />
                        </div>
                      </div>
                      <p class="text-right pt-3">
                        Fuente de Cifras: Secretaría de Movilidad
                      </p>
                    </b-col>
                  </b-row>
                </div>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>
     
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-6">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row >
            <b-col xl="6" md="12" col class="mt-lg-5">
              <div class="position-relative">
                <div class="text-left">
                  <img
                    src="recursos/img/Fondo02.png"
                    alt=""
                    class="img-fluid animado animado-Ab animate__animated animate__fadeIn position-absolute"
                  />
                </div>

                <div class="p-5 my-5 my-lg-5">
                  <img
                    src="recursos/img/Ciclista.png"
                    alt=""
                    class="img-fluid ciclistaM2 animado m-0 animado-Iz animate__animated animate__bounceInLeft animate__delay-2s w-50 position-absolute p-4 p-lg-5"
                  />
                </div>
              </div>
            </b-col>
            <b-col xl="6" md="12" cols="12" class="">
              <div class="px-5 py-5 d-flex align-items-center">
                <div class="p-4 sombra1 mt-5">
                  <div
                    class="row justify-content-center align-items-center border1 rounded p-3"
                  >
                    <div class="col-lg-4 col-12 text-center">
                      <img
                        class="img-fluid mb-5"
                        src="recursos/img/Para_no_olvidar.png"
                        alt=" "
                      />
                    </div>
                    <div class="col-lg-8 col-12">
                      <div class="">
                        <h5 class="col_t1">Para no olvidar</h5>
                        <p>
                          La vía es de todos, podemos convivir de manera segura
                          en la vía, los incidentes viales los podemos prevenir,
                          no podemos perder más vidas.
                        </p>

                        <h5 class="col_t4">¡Depende de ti y de mí!</h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>

			<div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-7">
				<b-container class="bv-example-row-flex-cols">
					<b-row class="py-5 justify-content-center">
						<b-col xl="12" lg="12" md="12" col align-self="center">
							<h3 class="col_t1 text-center">
								Elementos humanos y <br /> físicos de la 
								movilidad
							</h3>
							</b-col>	

							</b-row>

						<b-row>
							<b-col>
								<b-card-group deck>
									<b-card class="animate__animated animate__bounceInDown animate__delay-1s" title="Humanos:" img-src="recursos/img/Movilidad_M1_011_img01.png" img-alt="Image" img-top>
									<b-card-text class="d-flex justify-content-center">

										<figure class="figure m-1 text-center">
										<b-img src="recursos/img/peaton_icon.svg" class="img-fluid" alt="" />
										<figcaption class="col_t1">Peatón</figcaption>							
										</figure>

										<figure class="figure m-1 text-center">
										<b-img src="recursos/img/pasajero_icon.svg" alt="" />
										<figcaption class="col_t1">Pasajero</figcaption>									
										</figure>

										<figure class="figure m-1 text-center">
										<b-img src="recursos/img/conductor_icon.svg" alt="" />
										<figcaption class="col_t1">Conductor</figcaption>								
										</figure>

										<figure class="figure m-1 text-center">
										<b-img src="recursos/img/agente_icon.svg" alt="" />
											<figcaption class="col_t1">Agente de <br> transito</figcaption>					
										</figure>	

									</b-card-text>
									</b-card>

									<b-card class="animate__animated animate__bounceInUp animate__delay-2s" title="Físicos:" img-src="recursos/img/Movilidad_M1_011_img02.png" img-alt="Image" img-top >
									<b-row align-v="center">
										<b-col class="text-center">
                                        <figure class="figure m-1 text-center">
										<b-img src="recursos/img/carro_icon.svg" alt="" />
											<figcaption class="col_t1">Vehículo</figcaption>					
										</figure>	<figure class="figure m-1 text-center">
										<b-img src="recursos/img/calle_icon.svg" alt="" />
											<figcaption class="col_t1">Vía</figcaption>					
										</figure>	
										</b-col>
									</b-row>						
									</b-card>
								</b-card-group>
							</b-col>
						</b-row>
				</b-container>
			</div>
	
			<div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-8">
				<b-container fluid class="bv-example-row bv-example-row-flex-cols">
					<b-row align-h="center">
						<b-col xl="6" md="12" cols="12" class="mt-lg-5">
              <div class="position-relative">
                <div class="text-left">
                  <img
                    src="recursos/img/Fondo03.png"
                    alt=""
                    class="img-fluid animado animado-Ab animate__animated animate__fadeIn position-absolute"
                  />
                </div>

                <div class="text-right">
                  <img
                    src="recursos/img/Agente_silbato.png"
                    alt=""
                    class="img-fluid agenteM1 animado m-0 animado-Iz animate__animated animate__bounceInLeft animate__delay-2s position-absolute p-4 p-lg-5"
                  />
                </div>
              </div>
            </b-col>
						<b-col xl="6" md="12" cols="12" class="">
							<h3 class="col_t1 mt-5">
								Factores de riesgos y causas de incidentalidad
							</h3>
							<p>Los factores de riesgo son las principales causas de siniestros con fatalidades o lesiones graves, por eso es importante que los identifiquemos a continuación:</p>
							<h6 class="text-center font-italic">
								Haz clic en los títulos para visualizar toda la información
							</h6>

						<b-row align-h="center">
							<b-col xl="10" md="12" cols="12">
								<div class="accordion my-5" role="tablist">
									<b-card no-body class="">
										<b-card-header header-tag="header" class="p-0" role="tab">
											<b-button
												block
												v-b-toggle.accordion-1
												class="btnColapsable"
												>Los riesgos por comportamientos humanos</b-button
											>
										</b-card-header>
										<b-collapse
											id="accordion-1"
											visible
											accordion="my-accordion"
											role="tabpanel"
										>
											<b-card-body>
											<p>
												Los comportamientos de los ciudadanos en la vía pública generan factores de protección, o factores de riesgo que afectan la preservación de la vida propia y de los demás.
											</p>
												<p>
													Es importante que al momento de conducir evites los
													siguientes comportamientos:
												</p>
												<p>
													La distracción. Es un factor de riesgo muy
													importante y bastante común. Ejemplos de
													distracción: encender un cigarrillo, discutir con
													otros, escuchar música con auriculares, caminar
													mirando el celular, colocarse el cinturón con el
													vehículo en marcha, hablar por celular mientras se
													conduce, beber o comer mientras se conduce, entre
													otros. Al distraernos aumentamos el tiempo y la
													distancia de frenado, lo que supone mayor riesgo de
													colisión o pérdida de control.
												</p> <br><br>
												<iframe width="100%" height="480" src="https://www.youtube.com/embed/U7O6XZWtMFk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
											</b-card-body>
										</b-collapse>
									</b-card>

									<b-card no-body class="mb-0">
										<b-card-header header-tag="header" class="p-0" role="tab">
											<b-button
												block
												v-b-toggle.accordion-2
												class="btnColapsable"
												>Comportamientos que debemos evitar</b-button
											>
										</b-card-header>
										<b-collapse
											id="accordion-2"
											accordion="my-accordion"
											role="tabpanel"
										>
											<b-card-body>
											<b-row>
												<b-col lg="5" cols="12">
													<figure>
														<img src="recursos/img/Agente_pare.png" class="img-fluid" alt="">
														
													</figure>
												</b-col>
												<b-col lg="7" cols="12">
													

														<ul>
															<li>No respetar la prelación.</li>
															<li>No respetar la distancia.</li>
															<li>Cambios bruscos de carril.</li>
															<li>Cruzar por sitios prohibidos.</li>
															<li>Cruzar la vía o intersección con semáforo en rojo.</li>
															<li>Exceder de velocidad.</li>
															<li>No usar cinturón de seguridad.</li>
															<li>Conducir bajo efectos de alcohol y/o sustancias alucinógenas.</li>
															<li>Tener exceso de confianza.</li>
															<li>Descuidar los puntos ciegos del vehículo.</li>
															<li>No usar sistemas de retención infantil.</li>
															<li>Conducir sin la suficiente pericia.</li>
															<li>Detenerse en la vía sin usar la señalización reglamentaria.</li>
															<li>Conducir cansado o con fatiga física o mental.</li>
															
														</ul>												
												</b-col>
											</b-row>
											</b-card-body>
										</b-collapse>
									</b-card>
									<b-card no-body class="mb-0">
										<b-card-header header-tag="header" class="p-0" role="tab">
											<b-button
												block
												v-b-toggle.accordion-3
												class="btnColapsable"
												>Riesgos por el estado de los vehículos</b-button
											>
										</b-card-header>
										<b-collapse
											id="accordion-3"
											accordion="my-accordion"
											role="tabpanel"
										>
											<b-card-body>
											<b-row>
												<b-col lg="5" cols="12">
													<figure>
														<img src="recursos/img/Movilidad_012_img02.png" class="img-fluid" alt="">
														<figcaption>uslikajme (2015) Vehículo varado. Recuperado de <b-link href="https://pixabay.com/es/photos/coche-fuego-bomberos-vehiculo-2593538/">https://pixabay.com/es/photos/coche-fuego-bomberos-vehiculo-2593538/</b-link> </figcaption>
													</figure>
												</b-col>
												<b-col lg="7" cols="12">
													<p>
														La falta de mantenimiento del vehículo, es un factor de riesgo que incide directamente en el incidente, donde se puede presentar una avería o daño que no permita al conductor responder adecuadamente ante una situación de peligro. <br>

														<ul>
															<li>Fallas mecánicas en el sistema de frenado, tracción, suspensión, dirección.</li>
															<li>Llantas en mal estado o con la presión de aire inadecuada.</li>
															<li>Falta de espejos retrovisores.</li>
															<li>Fallas en sistema de luces.</li>
															<li>Fugas de aceite o líquidos.</li>
															<li>Piezas del vehículo sueltas.</li>
															<li>Ausencia de elementos de seguridad en el vehículo como airbags, ABS, control electrónico de estabilidad, cinturones de seguridad o apoya cabezas.</li>
														</ul>
													</p>
												</b-col>
											</b-row>
											</b-card-body>
										</b-collapse>
									</b-card>

									<b-card no-body class="mb-0">
										<b-card-header header-tag="header" class="p-0" role="tab">
											<b-button
												block
												v-b-toggle.accordion-4
												class="btnColapsable"
												>Riesgos por la infraestructura</b-button
											>
										</b-card-header>
										<b-collapse
											id="accordion-4"
											accordion="my-accordion"
											role="tabpanel"
										>
											<b-card-body>
												<b-row>
												<b-col lg="5" cols="12">
													<figure>
														<img src="recursos/img/Movilidad_012_img03.png" class="img-fluid" alt="">
														<figcaption>Vía en mal estado: Recuperado de <b-link href="https://pxhere.com/es/photo/946212">https://pxhere.com/es/photo/946212</b-link> </figcaption>
													</figure>
												</b-col>
												<b-col lg="7" cols="12">
													<p>
														Son aquellos factores que están asociados al entorno físico o al estado de la vía; también se constituyen en un riesgo que puede causar un incidente. Algunos factores de riesgo asociados a la infraestructura son:  <br>

														<ul>
															<li>El trazado de las vías: rectas o curvas cerradas.</li>
															<li>El estado del asfalto, hundimientos o huecos.</li>
															<li>La falta o deterioro en la señalización.</li>
															<li>La ausencia de iluminación.</li>
															<li>Los objetos que se presentan en una vía o en un andén como árboles, ramas, raíces, rocas, postes, entre otros.</li>
														</ul>
													</p>
												</b-col>
											</b-row>
											</b-card-body>
										</b-collapse>
									</b-card>

									<b-card no-body class="mb-0">
										<b-card-header header-tag="header" class="p-0" role="tab">
											<b-button
												block
												v-b-toggle.accordion-5
												class="btnColapsable"
												>Riesgos por condiciones meteorológicas</b-button
											>
										</b-card-header>
										<b-collapse
											id="accordion-5"
											accordion="my-accordion"
											role="tabpanel"
										>
											<b-card-body>
												<b-row>
												<b-col lg="5" cols="12">
													<figure>
														<img src="recursos/img/Movilidad_012_img04.png" class="img-fluid" alt="">
														<figcaption>Conducción bajo lluvia: Recuperado de <b-link href="https://www.piqsels.com/es/public-domain-photo-ogarp">https://www.piqsels.com/es/public-domain-photo-ogarp</b-link> </figcaption>
													</figure>
												</b-col>
												<b-col lg="7" cols="12">
													<p>
														Tienen un impacto significativo en el número de incidentes viales. En algunos casos, las condiciones meteorológicas pueden generar un mayor riesgo para el peatón, como: <br>

														<ul>
															<li>La lluvia.</li>
															<li>El viento.</li>
															<li>La neblina.</li>
															<li>La noche.</li>
															
														</ul>
													</p>
												</b-col>
											</b-row>
											</b-card-body>
										</b-collapse>
									</b-card>
								</div>
							</b-col>
						</b-row>
						</b-col>
					</b-row>
				</b-container>
			</div>
		
			<div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-9">
				<b-container fluid class="bv-example-row bv-example-row-flex-cols">
					<b-row >
						<b-col xl="7" md="12" col class="mt-lg-5">
							<div class="text-right">
								<img src="recursos/img/Movilidad_M1_018.png" alt="" class="img-fluid animado animado-Arr animate__animated animate__fadeIn "/>
							</div>	  
						</b-col>
						<b-col xl="5" md="12" cols="12" class="pt-5">
							<div class="px-5 pt-5">
								<div class="sombra1 p-4">
									<div class="row justify-content-center align-items-center border1 rounded p-3">
										<div class="col-lg-2 col-12 text-center">
											<img class="img-fluid mb-5" src="recursos/img/Para_no_olvidar.png" alt=" "/>
										</div>
										<div class="col-lg-10 col-12">
											<h3 class="col_t1">Para no olvidar</h3>
											<p>En época de lluvia aumenta las medidas de precaución, disminuye la velocidad y evita los charcos, éstos pueden ser peligrosos.</p>

											<h5 class="col_t4">¡Depende de ti y de mí!</h5>
										</div>
									</div>
								</div>
								
							</div>
						</b-col>
					</b-row>
				</b-container>
			</div>
			
			<div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-10">
				<b-container class="bv-example-row bv-example-row-flex-cols">
					<b-row class="mprin2 justify-content-center">
						<b-col xl="10" lg="10"  cols="12" align-self="center">
							<figure>
								<img src="recursos/img/Movilidad_M1_019.png" class="img-fluid d-none d-md-block" alt="">
								<img src="recursos/img/Movilidad_M1_019_cel.png" class="img-fluid d-block d-md-none" alt="">
							</figure>
						</b-col>
					</b-row>
				</b-container>
			</div>
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-11">
				<b-container fluid class="bv-example-row bv-example-row-flex-cols">
					<b-row align-h="center"  class="margen_principal">
						<b-col xl="12" md="12" cols="12">
							<div class="pl-lg-5">
								<h2 class="col_t1"> <img src="recursos/img/actividad_icon.svg" class="img-fluid" alt=""> Actividad de interacción</h2>
								
								<p>
									identifica en las imágenes y textos los tipos de riesgos que
									generan incidentes viales.
								</p>
								<h4>Tipo de actividad</h4>
								<p>Selección múltiple por menú desplegable</p>
								<h4>Instrucción</h4>

								<p>
									Selecciona la opción correcta de acuerdo con las siguientes
									alternativas.
									<ul>
									<li>Opción 1: Riesgos por comportamientos humanos.</li>
									<li>Opción 2: Riesgos por estados del vehículo.</li>
									<li>Opción 3: Riesgos por la infraestructura.</li>
									<li>Opción 4: Riesgos por condiciones metrológicas.</li>
									</ul>
									
								</p>
							</div>
						</b-col>
						<b-col xl="12" md="12" cols="12" class="my-5">
							<div class="swiper-container-2 overflow-hidden">
								<div class="swiper-wrapper">
									<!--SLIDE 1-->
									<div class="swiper-slide swiper-no-swiping">
										<b-row align-h="center p-3">
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img01.png" alt="" class="img-fluid ">
												<p>Conductor usando el celular</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_1" v-model="opcionSeleccionada1" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_1 resultado_1_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_1 resultado_1_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img02.png" alt="" class="img-fluid ">
												<p>Conductor conversando con copiloto mientras maneja</p>
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_2" v-model="opcionSeleccionada2" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_2 resultado_2_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_2 resultado_2_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img03.png" alt="" class="img-fluid ">
												<p>Una caja en la vía</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_3" v-model="opcionSeleccionada3" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_3 resultado_3_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_3 resultado_3_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
										</b-row>
										<b-row align-h="center p-3">
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img04.png" alt="" class="img-fluid ">
												<p>Un conductor con mala postura y cansado</p>
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_4" v-model="opcionSeleccionada4" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_4 resultado_4_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_4 resultado_4_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img05.png" alt="" class="img-fluid ">
												<p>Peatón pasando calle con audífonos y manipulando celular</p>
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_5" v-model="opcionSeleccionada5" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_5 resultado_5_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_5 resultado_5_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img06.png" alt="" class="img-fluid ">
												<p>Un conductor con sueño</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_6" v-model="opcionSeleccionada6" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_6 resultado_6_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_6 resultado_6_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
										</b-row>


										<b-row align-h="center p-3">
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img07.png" alt="" class="img-fluid ">
												<p>Exceso de velocidad</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_7" v-model="opcionSeleccionada7" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_7 resultado_7_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_7 resultado_7_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img08.png" alt="" class="img-fluid ">
												<p>Vehículo regando aceite</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_8" v-model="opcionSeleccionada8" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_8 resultado_8_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_8 resultado_8_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img09.png" alt="" class="img-fluid ">
												<p>Actor vial gritando</p>
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_9" v-model="opcionSeleccionada9" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_9 resultado_9_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_9 resultado_9_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
										</b-row>
										
										<b-row align-h="end">
											<b-col class=""  lg="3" cols="12"><button type="button" class="btn btn_siguiente btn1">Siguiente</button></b-col>
										</b-row>
									</div>
									<!--FIN SLIDE 1-->

									<!--SLIDE 2-->
									<div class="swiper-slide swiper-no-swiping">
										<b-row align-h="center">
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img010.png" alt="" class="img-fluid ">
												<p>Bus parando en lugar no permitido</p>
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_10" v-model="opcionSeleccionada10" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_10 resultado_10_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_10 resultado_10_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img011.png" alt="" class="img-fluid ">
												<p>Vehículo con exceso de carga o carga sobredimensionada</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_11" v-model="opcionSeleccionada11" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_11 resultado_11_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_11 resultado_11_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img012.png" alt="" class="img-fluid ">
												<p>Dejar estacionado un carro en lugar prohibido donde se afecte la movilidad</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_12" v-model="opcionSeleccionada12" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_12 resultado_12_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_12 resultado_12_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img013.png" alt="" class="img-fluid ">
												<p>Un carro en mal estado</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_13" v-model="opcionSeleccionada13" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_13 resultado_13_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_13 resultado_13_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img014.png" alt="" class="img-fluid ">
												<p>Peatón cruzando por sitios prohibidos</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_14" v-model="opcionSeleccionada14" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_14 resultado_14_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_14 resultado_14_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img015.png" alt="" class="img-fluid ">
												<p>Vía con huecos</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_15" v-model="opcionSeleccionada15" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_15 resultado_15_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_15 resultado_15_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img016.png" alt="" class="img-fluid ">
												<p>Una vía pública, con un carro desplazándose con lluvia y congestión</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_16" v-model="opcionSeleccionada16" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_16 resultado_16_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_16 resultado_16_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img017.png" alt="" class="img-fluid ">
												<p>Un conductor sin cinturón de seguridad</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_17" v-model="opcionSeleccionada17" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_17 resultado_17_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_17 resultado_17_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img018.png" alt="" class="img-fluid ">
												<p>Un carro sin frenos</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_18" v-model="opcionSeleccionada18" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_18 resultado_18_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_18 resultado_18_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
										</b-row>
										<b-row align-h="end">
							
											<b-col class=""  lg="2" cols="12"><button type="button" class="btn btn_atras btn1">Anterior</button></b-col>
											<b-col class=""  lg="2" cols="12"><button type="button" class="btn btn_siguiente btn1">Siguiente</button></b-col>
										</b-row>
									</div>
									<!--FIN SLIDE 2-->

									<!--SLIDE 3-->
									<div class="swiper-slide swiper-no-swiping">
										<b-row align-h="center">
											<b-col class="sombra1 rounded p-5 text-center m-2"  lg="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img019.png" alt="" class="img-fluid ">
												<p>Conducción con neblina</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_19" v-model="opcionSeleccionada19" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_19 resultado_19_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_19 resultado_19_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  lg="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img020.png" alt="" class="img-fluid ">
												<p>Carretera sin señalización</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_20" v-model="opcionSeleccionada20" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_20 resultado_20_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_20 resultado_20_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  lg="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img021.png" alt="" class="img-fluid ">
												<p>Un derrumbe en la carretera</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_21" v-model="opcionSeleccionada21" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_21 resultado_21_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_21 resultado_21_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  lg="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img022.png" alt="" class="img-fluid ">
												<p>Una moto emitiendo mucho ruido</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_22" v-model="opcionSeleccionada22" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_22 resultado_22_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_22 resultado_22_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>

											<b-col class="sombra1 rounded p-5 text-center m-2"  lg="3" cols="12">
												<img src="recursos/img/Movilidad_M1_019_Actividad_img023.png" alt="" class="img-fluid ">
												<p>Vía con curvas</p> 
												<b-form-select @change.native="validaSelect($event)" class="classic select_items selectCP w-50 d-flex mx-auto" id="selectCP_23" v-model="opcionSeleccionada23" :options="options"></b-form-select>
												<b-row>
													<b-col class="d-flex justify-content-center mt-3">
														<div class="resultado_23 resultado_23_pos d-none w-100"><b-alert show variant="success">Respuesta correcta</b-alert></div>
														<div class="resultado_23 resultado_23_neg d-none w-100"><b-alert show variant="danger">Respuesta incorrecta</b-alert></div>
													</b-col>
												</b-row>
											</b-col>
																			
										</b-row>
										<b-row align-h="end">
							
											<b-col class=""  lg="2" cols="12"><button type="button" class="btn btn_atras btn1">Anterior</button></b-col>
											
										</b-row>
										
									</div>
									<!--FIN SLIDE 3-->
								</div>
							</div>
						</b-col>
					</b-row>
				</b-container>
			</div>

      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-12">
				<b-container fluid class="bv-example-row bv-example-row-flex-cols">
					<b-row align-v="center" class="margen_principal">
						<b-col xl="12" md="12" cols="12">
							<div class="px-5">
								<h3 class="col_t1"> <img src="recursos/img/actividad_icon.svg" class="img-fluid" alt=""> Actividad de interacción 2</h3>
								
								<p>
									identifica en las situaciones de riesgos que generan incidentes viales
								</p>
								<h4>Tipo de actividad</h4>
								<p>emparejamiento numérico</p>
								<h4>Instrucción</h4>

								<p>
									identifica las siguientes situaciones, selecciona o digita el número correcto sobre a imagen 
									<ol>
										<li>No utilización del casco para motociclista</li>
										<li>Vía en reparación o mal estado</li>
										<li>Animales en la vía</li>
										<li>Falla mecánica</li>
										<li>Parquear en zona prohibida</li>
										<li>Uso de celular</li>
										<li>Hueco en la vía</li>
									</ol>
								</p>
							</div>
						</b-col>
						<b-col xl="12" md="12" cols="12" class="my-5">
							<div class="swiper-container-2 overflow-hidden">
								<div class="swiper-wrapper">
									<!--SLIDE 1-->
									<div class="swiper-slide swiper-no-swiping">
										<b-row align-h="center p-3">
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<input type="number" min="1" max="7" class="form-control text-center mb-3 inputs" placeholder="Ingresar número">
												<img src="recursos/img/Movilidad_M1_021_Actividad_img01.png" alt="" class="img-fluid">
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<input type="number" min="1" max="7" class="form-control text-center mb-3 inputs" placeholder="Ingresar número">
												<img src="recursos/img/Movilidad_M1_021_Actividad_img07.png" alt="" class="img-fluid">
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<input type="number" min="1" max="7" class="form-control text-center mb-3 inputs" placeholder="Ingresar número">
												<img src="recursos/img/Movilidad_M1_021_Actividad_img02.png" alt="" class="img-fluid">
											</b-col>
										</b-row>
										<b-row align-h="center p-3 mt-xl-0 mt-lg-0 mt-n4">
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<input type="number" min="1" max="7" class="form-control text-center mb-3 inputs" placeholder="Ingresar número">
												<img src="recursos/img/Movilidad_M1_021_Actividad_img05.png" alt="" class="img-fluid">
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<input type="number" min="1" max="7" class="form-control text-center mb-3 inputs" placeholder="Ingresar número">
												<img src="recursos/img/Movilidad_M1_021_Actividad_img04.png" alt="" class="img-fluid">
											</b-col>
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<input type="number" min="1" max="7" class="form-control text-center mb-3 inputs" placeholder="Ingresar número">
												<img src="recursos/img/Movilidad_M1_021_Actividad_img06.png" alt="" class="img-fluid">
											</b-col>
										
										</b-row>

										<b-row align-h="center p-3 mt-xl-0 mt-lg-0 mt-n4">
											<b-col class="sombra1 rounded p-5 text-center m-2"  xl="3" cols="12">
												<input type="number" min="1" max="7" class="form-control text-center mb-3 inputs" placeholder="Ingresar número">
												<img src="recursos/img/Movilidad_M1_021_Actividad_img03.png" alt="" class="img-fluid">
											</b-col>
										</b-row>
										<b-row><b-col class="d-none text-center" id="mensajeError"><b-alert show variant="danger">¡Debe terminar toda la actividad!</b-alert></b-col></b-row>
										<b-row align-h="end">
											<b-col class="" @click="comprobar1"  lg="3" cols="12"><button type="button" class="btn btn_siguiente btn1">Comprobar</button></b-col>
										</b-row>
									</div>
									<!--FIN SLIDE 1-->

								</div>
							</div>
						</b-col>
					</b-row>
				</b-container>
			</div>
        <Modales :tituloResultado="tituloResultado" :descripcionResultado="descripcionResultado" :imgURL="imgURL"/>

        
      <div class="swiper-slide overflow-auto swiper-no-swiping" data-title="" id="slide-13">
        <b-container class="bv-example-row bv-example-row-flex-cols">
          <b-row class=" justify-content-center">
            <b-col cols="12"
              ><h3 class="col_t1 mt-5">Incidentes viales</h3>
              <br />
              <p>
                Evento generalmente involuntario, causado al menos por un
                vehículo en movimiento, que causa daños a personas y bienes
                involucrados en él e igualmente afecta la normal circulación de
                los vehículos que se movilizan por la vía o dentro de la zona de
                influencia del hecho. (Definición es tomada del Código Nacional
                de Tránsito Terrestre. Ley 769 del 2002, artículo 2.)
                <br /><br />
                Es importante resaltar, que los incidentes viales causan graves
                consecuencias para los involucrados. Algunas de ellas son:
              </p>
            </b-col>
          </b-row>
          <b-row class=" py-5">
            <b-col
              class="animate__animated animate__bounceInDown animate__delay-1s"
              lg="6"
              sm="12"
              cols="12"
            >
              <div class="cuadro1 p-3 rounded">
                <b-row class="" align-h="center">
                  <b-col align-self="center" lg="3" cols="12">
                    <img
                      src="recursos/img/Movilidad_M1_022_01.png"
                      class="img-fluid"
                      alt=""
                    />
                  </b-col>
                  <b-col lg="9" cols="12">
                    <h4 class="col_t1">Muerte</h4>
                    <p class="col_t5">
                      provocar la muerte de alguien es la consecuencia más grave
                      de un incidente, y el responsable podría enfrentarse a
                      penas de prisión.
                    </p>
                  </b-col>
                </b-row>
              </div>
            </b-col>
            <b-col
              class="animate__animated animate__bounceInDown animate__delay-1s"
              lg="6"
              sm="12"
              cols="12"
            >
              <div class="cuadro2 p-3 rounded">
                <b-row class="" align-h="center">
                  <b-col align-self="center" lg="3" cols="12">
                    <img
                      src="recursos/img/Movilidad_M1_022_02.png"
                      class="img-fluid"
                      alt=""
                    />
                  </b-col>
                  <b-col lg="9" cols="12">
                    <h4 class="col_t1 pt-3">Lesionados</h4>
                    <p class="col_t5 pt-3">
                      los incidentes pueden generar discapacidades de por vida.
                    </p>
                  </b-col>
                </b-row>
              </div>
            </b-col>
            <b-col
              class="animate__animated animate__bounceInUp animate__delay-2s"
              lg="6"
              sm="12"
              cols="12"
            >
              <div class="cuadro3 p-3 rounded mt-1">
                <b-row class="" align-h="center">
                  <b-col align-self="center" lg="3" cols="12">
                    <img
                      src="recursos/img/Movilidad_M1_022_03.png"
                      class="img-fluid"
                      alt=""
                    />
                  </b-col>
                  <b-col lg="9" cols="12">
                    <h4 class="col_t1">Daños materiales</h4>
                    <p class="col_t5">
                      los incidentes pueden generar un deterioro en el
                      patrimonio económico de una persona.
                    </p>
                  </b-col>
                </b-row>
              </div>
            </b-col>
            <b-col
              class="animate__animated animate__bounceInUp animate__delay-2s"
              lg="6"
              sm="12"
              cols="12"
            >
              <div class="p-3 cuadro4 rounded">
                <b-row class="" align-h="center">
                  <b-col align-self="center" lg="3" cols="12">
                    <img
                      src="recursos/img/Movilidad_M1_022_04.png"
                      class="img-fluid"
                      alt=""
                    />
                  </b-col>
                  <b-col lg="9" cols="12">
                    <h4 class="text-white mb-5">Daños morales</h4>
                    <p class="text-white">
                      los incidentes pueden causar en los involucrados traumas o
                      afectaciones psicológicas que les impiden desarrollar la
                      vida de una manera normal.
                    </p>
                  </b-col>
                </b-row>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>

   
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-14">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row >
             <b-col xl="6" md="12" col class="mt-lg-5">
              <div class="position-relative">
                <div class="text-left">
                  <img
                    src="recursos/img/Fondo01.png"
                    alt=""
                    class="img-fluid animado animado-Ab animate__animated animate__fadeIn position-absolute"
                  />
                </div>

                <div class="p-5 my-5 my-lg-5">
                  <img
                    src="recursos/img/Conductor.png"
                    alt=""
                    class="img-fluid animado m-0 animado-Iz animate__animated animate__bounceInLeft animate__delay-2s position-absolute p-4 p-lg-5"
                  />
                </div>
              </div>
            </b-col>
            <b-col xl="6" md="12" cols="12" class="py-5">
              <div class="px-5">
                <div class="sombra1 p-4 mt-xl-0 mt-lg-0 mt-3 rounded">
                  <div
                    class="row justify-content-center align-items-center border1 rounded p-3"
                  >
                    <div class="col-lg-4 col-12 text-center">
                      <img
                        class="img-fluid mb-5"
                        src="recursos/img/Para_no_olvidar.png"
                        alt=" "
                      />
                    </div>
                    <div class="col-lg-8 col-12">
                      <h5 class="col_t1">Para no olvidar</h5>
                      <p>
                        Cuando eres el causante de un accidente debes responder
                        con tu patrimonio o tu libertad por los daños
                        económicos, físicos y morales que generes.
                      </p>
                      <h5 class="text-center col_t4">
                        ¡Depende de ti y de mí!
                      </h5>
                    </div>
                  </div>
                </div>
                <div class="sombra1 p-4 mt-4 rounded">
                  <div
                    class="row justify-content-center align-items-center border1 rounded p-3"
                  >
                    <div class="col-lg-4 col-12 text-center">
                      <img
                        class="img-fluid mb-5"
                        src="recursos/img/Lecturas.png"
                        alt=" "
                      />
                    </div>
                    <div class="col-lg-8 col-12">
                      <h5 class="col_t1">Lectura complementaria de interés:</h5>
                      <p>
                        Estadísticas de interés: Estudio de percepción. En
                        Colombia, “predomina la emoción sobre la razón”
                      </p>
                      <b-button
                        v-b-modal.modal-lecturaComplementaria
                        class="btn btn1 d-flex mx-auto"
                        >Leer</b-button
                      >
                    </div>
                  </div>
                </div>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>

      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-15">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row >
             <b-col xl="6" md="12" col class="mt-lg-5">
              <div class="position-relative">
                <div class="text-left">
                  <img
                    src="recursos/img/Fondo01.png"
                    alt=""
                    class="img-fluid animado animado-Ab animate__animated animate__fadeIn position-absolute"
                  />
                </div>

                <div class="">
                  <img
                    src="recursos/img/Agente_pare.png"
                    alt=""
                    class="img-fluid agenteM1 animado m-0 animado-Iz animate__animated animate__bounceInLeft w-50 animate__delay-2s position-absolute p-4 p-lg-5"/>

                 

                </div>
              </div>
            </b-col>
            <b-col xl="6" md="12" col>
              <div class="p-5">
                <p class="mb-4 font-italic text-center mt-xl-0 mt-lg-0 mt-5">
                  Haz clic en los círculos para visualizar la información
                  completa
                </p>
                <div class="p-4 mt-xl-0 mt-lg-0 mt-3">
                  <div
                    class="row justify-content-center align-items-center sombra1  rounded p-3"
                  >
                    <div class="col-12 text-center">
                      <h4 class="col_t1 text-left">Para tener en cuenta</h4>
                      <p class="text-left mb-5">
                        Un buen comportamiento puede evitar un incidente vial y
                        salvar vidas.
                      </p>
                      <carousel
                        :per-page="1"
                        :navigate-to="someLocalProperty"
                        :mouse-drag="false"
                      >
                        <slide
                          ><p class="text-left">
                            <b>• Sé responsable al volante:</b> no hables por
                            celular, no fumes ni ingieras drogas, alcohol o
                            fármacos mientras se conduce. Respeta en todo
                            momento los límites de velocidad que corresponden a
                            cada tipo de vía.
                          </p></slide
                        >
                        <slide
                          ><p class="text-left">
                            <b>• Evita conducir de forma agresiva:</b> no hagas
                            uso del pito, gestos o comentarios exagerados, no
                            adelantes sin guardar las distancias y, no realices
                            carreras con otros vehículos en un afán de
                            superioridad.
                          </p></slide
                        >
                        <slide
                          ><p class="text-left">
                            <b>• Conduce de manera cívica y responsable:</b>
                            indica debidamente y con antelación los giros,
                            detenciones y adelantamientos; haz un uso adecuado
                            de las luces.
                          </p></slide
                        >
                        <slide
                          ><p class="text-left">
                            <b>• Mantén una posición correcta:</b> circula por
                            el carril adecuado, cede el paso, facilita las
                            incorporaciones y atiende las señales de tránsito.
                          </p></slide
                        >
                        <slide
                          ><p class="text-left">
                            <b>• No conduzcas de forma descuidada:</b> no cortes
                            la trayectoria a otros vehículos cuando realice
                            maniobras de desplazamiento y no hagas giros
                            indebidos.
                          </p></slide
                        >
                        <slide
                          ><p class="text-left">
                            <b>• Descansa:</b> para conducir es necesario estar
                            descansado y con la mejor disposición.
                          </p></slide
                        >
                      </carousel>
                    </div>
                  </div>
                </div>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>


    
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-16">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row align-v="center">
            <b-col xl="6" md="12" class="Fondo-actores">
              <span class="ref1"
                >Fuente de imágenes: Archivo fotográfico de Secretaría de
                Movilidad
              </span>
            </b-col>
            <b-col xl="6" md="12" cols="12">
              <b-row align-v="center">
                <b-col cols="12">
                  <div class="px-5">
                    <h3 class="col_t1 mt-xl-0 mt-lg-0 mt-5">Actores viales</h3>
                    <p>
                      Son actores viales todas las personas que asumen un rol
                      determinado, para hacer uso de las vías, con la finalidad
                      de desplazarse de un lugar a otro; por lo tanto, se
                      consideran actores de tránsito y de la vía los peatones,
                      los pasajeros y conductores de vehículos automotores y no
                      automotores, los motociclistas, los ciclistas, los
                      acompañantes, entre otros (Corporación Fondo de Prevención
                      Vial, 2011, citado por Ministerio de Transporte, 2015, p
                      53).
                    </p>
                  </div>
                </b-col>
              </b-row>
            </b-col>
          </b-row>
        </b-container>
      </div>

     
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-17">
        <b-container class="bv-example-row bv-example-row-flex-cols">
          <b-row class="margen_principal justify-content-center">
            <b-col xl="12" lg="12" md="12" col align-self="center">
              <div class="text-center">
                <b-carousel
                  :per-page="1"
                  :navigate-to="someLocalProperty"
                  :mouse-drag="false"
                  v-model="slide"
                  :interval="4000"
                  controls
                  indicators
                >
                  <b-carousel-slide
                    caption="First slide"
                    img-src="recursos/img/Movilidad_M1_029_img01.png"
                    caption-html="<p class='text-left p-3' style='color:#333;background:rgba(255,255,255,0.5);'>
                              <b>Conductor</b> <br />
                              Persona habilitada y capacitada técnica y
                              teóricamente para operar un vehículo.
                            </p>"
                  >
                  </b-carousel-slide>
                  <b-carousel-slide
                    caption="Second slide"
                    img-src="recursos/img/Movilidad_M1_029_img02.png"
                    caption-html="<p class='text-left p-3' style='color:#333;background:rgba(255,255,255,0.5);'>
                               <b>Motociclista</b> <br />
                              Persona que conduce un vehículo automotor de dos
                              ruedas en línea, con capacidad para el conductor y
                              un acompañante.
                            </p>"
                  >
                  </b-carousel-slide>
                  <b-carousel-slide
                    caption="thirth slide"
                    img-src="recursos/img/Movilidad_M1_029_img03.png"
                    caption-html="<p class='text-left p-3' style='color:#333;background:rgba(255,255,255,0.5);'>
                                <b>Ciclista</b><br />Toda persona que utiliza una
                              bicicleta como medio alternativo de transporte o
                              entretenimiento.
                            </p>"
                  >
                  </b-carousel-slide>
                  <b-carousel-slide
                    caption="Four slide"
                    img-src="recursos/img/Movilidad_M1_029_img04.png"
                    caption-html="<p class='text-left p-3' style='color:#333;background:rgba(255,255,255,0.5);'>
                                <b>Peatón</b> <br />
                              El peatón, es una persona que va a pie por una vía
                              pública.
                            </p>"
                  >
                  </b-carousel-slide>
                  <b-carousel-slide
                    caption="Five slide"
                    img-src="recursos/img/Movilidad_M1_029_img05.png"
                    caption-html="<p class='text-left p-3' style='color:#333;background:rgba(255,255,255,0.5);'>
                                <b>Agente de tránsito</b><br />Es la autoridad en
                              la vía y su función es velar por el orden del
                              flujo vehicular y peatonal, mediante funciones
                              preventivas, de asistencia técnica, vigilancia y
                              control de las normas de tránsito y transporte.
                            </p>"
                  >
                  </b-carousel-slide>
                </b-carousel>
                <b-row class="mt-3 ml-2">
                  <b-col class=""
                    ><p class="text-left">
                      Fuente de imágenes: Archivo fotográfico de Secretaría de
                      Movilidad
                    </p></b-col
                  >
                </b-row>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>

    
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-18">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row align-v="center">
            <b-col xl="6" md="12" class="p-0">
				<img
                    src="recursos/img/Movilidad_M1_031.png"
                    alt=""
                    class="img-fluid agenteM1 "
                  />
			</b-col>
            <b-col xl="6" md="12" cols="12" class="Fondo-actores3">
              <b-row align-v="center">
                <b-col cols="12">
                  <div class="px-5">
                    <h5 class="text-center mt-5">
                      La imagen nos muestra la prelación que tienen los actores
                      viales ubicando en la parte superior, aquellos con mayor
                      prelación sobre los demás.
                    </h5>
                  </div>
                </b-col>
              </b-row>
            </b-col>
          </b-row>
        </b-container>
      </div>

     
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-19">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row>
            <b-col xl="6" md="12" col class="mt-lg-5">
              <div class="">
                <div class="text-right">
                  <img
                    src="recursos/img/Movilidad_M1_018.png"
                    alt=""
                    class="img-fluid animado animado-Arr animate__animated animate__fadeIn "
                  />
                </div>
              </div>
            </b-col>
            <b-col xl="6" md="12" cols="12" class="pt-5">
              <div class="px-5">
                <h3 class="col_t1 mt-xl-0 mt-lg-0 mt-5 mb-3">
                  Manejo preventivo para la seguridad vial
                </h3>
                <p>
                  <b>El manejo preventivo se debe entender como las técnicas</b>
                  aplicadas a la conducción de un vehículo, que permiten la
                  percepción de peligros, reaccionar de manera correcta y tomar
                  las decisiones adecuadas salvando vidas y ahorrando tiempo y
                  dinero.
                </p>
                <p><b>Fórmula para afrontar intersecciones.</b></p>
                <p>
                  <b>. Anticipar:</b> Prelación. ¿Para dónde va? Carril
                  adecuado. <br />
                  <b>. Aplicar:</b> La velocidad permitida de acuerdo a las zona
                  por la que se transita o lo que indiquen las autoridades
                  <br />
                  <b>. Asegurar:</b> Conduzca protegiendo siempre la vida.
                  <br />
                  <b>. Advertir:</b> Comunique sus intenciones con tiempo.
                  <br />
                  <b>. Actuar:</b> Observe, analice, decida y avance con
                  precaución
                </p>
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>

     
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide-20">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row >
            <b-col xl="6" lg="6" md="12" cols="12" class="">
              <div class="">
                <div class="text-left">
                  <img
                    src="recursos/img/Fondo02.png"
                    alt=""
                    class="img-fluid animado animado-Ab animate__animated animate__fadeIn position-absolute"
                  />
                </div>

                <div class="p-5 mt-5 mt-lg-5">
                  <img
                    src="recursos/img/Ciclista.png"
                    alt=""
                    class="img-fluid ciclistaM2 animado m-0 animado-Iz animate__animated animate__bounceInLeft animate__delay-2s w-50 position-absolute p-4 p-lg-5 pt-5"
                  />
                </div>
              </div>
            </b-col>
            <b-col xl="6" lg="6" md="12" cols="12">
              <b-row align-v="center">
                <b-col cols="12">
                  <div class="p-5">
                    <h4 class="col_t1 mt-5 mb-3">
                      Los cinco minutos de vida.
                    </h4>
                    <p>
                      <b
                        >Antes de emprender un recorrido, debemos tener revisar
                        los siguientes elementos:</b
                      >
                    </p>
                    <p>
                      • El autodiagnóstico personal <br />
                      • Documentación del vehículo <br />
                      • Inspección visual exterior a la carrocería <br />
                      • Revisión de fluidos y sistema eléctrico <br />
                      • Ajuste asiento y retrovisores <br />
                      • Al encender revisar comandos del vehículo <br />
                      • En movimiento: Estar atento a cambios repentinos de
                      velocidad y ruidos generados al circular
                    </p>
                  </div>
                </b-col>
              </b-row>
            </b-col>
          </b-row>
        </b-container>
      </div>

     
      <div class="swiper-slide overflow-auto swiper-no-swiping" id="slide21">
        <b-container fluid class="bv-example-row bv-example-row-flex-cols">
          <b-row align-v="center">
            <b-col xl="6" md="12" col class="mt-lg-5">
              <div class="">
                <div class="text-right">
                  <img
                    src="recursos/img/Movilidad_M1_018.png"
                    alt=""
                    class="img-fluid animado animado-Arr animate__animated animate__fadeIn "
                  />
                </div>
              </div>
            </b-col>
            <b-col xl="6" md="12" cols="12" class="mt-lg-5">
              <div class="px-5">
                <h4 class="mb-3 col_t1 mt-xl-0 mt-lg-0 mt-5">
                  Conducción preventiva
                </h4>
                <p
                  class="mb-4 font-italic text-center mt-xl-0 mt-lg-0 mt-5 mb-"
                >
                  Haz clic en los círculos para visualizar la información
                  completa
                </p>
                <div class="sombra1 p-4 mt-xl-0 mt-lg-0 mt-3">
                  <div
                    class="row justify-content-center align-items-center border1 rounded p-3"
                  >
                    <div class="col-12 text-center">
                      <carousel
                        class="mt-5"
                        :per-page="1"
                        :navigate-to="someLocalProperty"
                        :mouse-drag="false"
                      >
                        <slide>
                          <h5 class="col_t1 text-left">¡Recuerda que…!</h5>
                          <p class="text-left">
                            La conducción preventiva significa no poner en
                            peligro la vida de los otros, y permite ahorrar
                            tiempo y dinero, a pesar de las condiciones
                            presentes. De este modo, la conducción preventiva
                            implica manejar de tal manera que se eviten
                            accidentes a pesar de las acciones de otros o de la
                            presencia de condiciones adversas para el conductor.
                          </p>
                          <p class="text-left">
                            Conducir de forma preventiva, es anticipar las
                            acciones de otros conductores y aplicar las técnicas
                            correctas de manejo según la situación que se
                            enfrenta.
                          </p>
                        </slide>
                        <slide>
                          <h5 class="col_t1 text-left">
                            ¡Pilas! Respira y No se deje llevar por factores que
                            lo impulsen a una conducción ofensiva
                          </h5>
                          <p class="text-left">
                            El objetivo de la conducción preventiva no puede
                            perderse de vista, a pesar de todos los factores y
                            condiciones que encontraremos al transitar por las
                            vías y que nos pueden inducir a una conducción
                            ofensiva, tales como: trancones, pavimento en mal
                            estado, conductores agresivos, distraídos,
                            señalización deficiente o poco visible, entre otros:
                            <b>debemos evitar incidentes y preservar la vida</b
                            >. Un incidente evitable es aquel, donde el
                            conductor hizo todo lo razonablemente posible para
                            que no sucediera.
                          </p>
                        </slide>
                        <slide>
                          <h5 class="col_t1 text-left">
                            Un conductor defensivo es aquel que:
                          </h5>
                          <p class="text-left">
                            • Conoce el Código Nacional de Tránsito. <br />
                            • Sabe técnicas de prevención de riesgos de
                            incidentes de tránsito. <br />
                            • Reconoce los peligros existentes en la vía. <br />
                            • Actúa correctamente y a tiempo. <br />
                            • Tiene agilidad mental.
                          </p>
                        </slide>
                        <slide>
                          <p class="text-left">
                            • Tiene conciencia respecto de las condiciones
                            físicas y mentales que podrían influir sobre su
                            manejo.<br />
                            • Permanece atento a las situaciones presentadas en
                            la vía, examinando constantemente los espejos
                            retrovisores, tanto interior como exterior.<br />
                            • Tiene la capacidad para anticiparse y prepararse
                            para enfrentar los peligros.<br />
                            • Analiza la situación del tránsito, tan adelante
                            como sea posible.<br />
                            • Anticipa a los peligros que se podrían presentar.
                          </p>
                        </slide>
                        <slide>
                          <p class="text-left">
                            • Decide si los cambios que se producen en la
                            situación del manejo constituyen una amenaza para su
                            seguridad.<br />
                            • Tomar decisiones sensatas y rápidas.<br />
                            • Busca alternativas en cualquier situación del
                            tránsito.<br />
                            • Mantiene control sobre su comportamiento.<br />
                            • Pasa o adelanta solamente cuando no hay
                            peligro.<br />
                            • No efectúa maniobras peligrosas.
                          </p>
                        </slide>
                      </carousel>
                    </div>
                  </div>
                </div>
                <p class="text-center mt-4 mb-4 font-italic">
                  Haz clic AQUÍ para conocer unas importantes recomendaciones:
                </p>
                <b-button
                  v-b-modal.modal-resultadosManejo
                  class="btn btn1 d-flex mx-auto"
                  >¿Aplicas adecuadamente las técnicas de conducción?</b-button
                >
              </div>
            </b-col>
          </b-row>
        </b-container>
      </div>
    </div>
  </div>
</template>
<style>
</style>
<script>
import { SwiperController } from "../assets/RecursosITM/js/Swiper";
import Modales from '@/components/Modales'
export default {
  name: "Tema1",
  data() {
    return {
      respuestasCorrectas1: [1, 7, 2, 5, 4, 6, 3],
      imgURL: "",
      tituloResultado: "",
      descripcionResultado: "",

      opcionSeleccionada1: null,
      opcionSeleccionada2: null,
      opcionSeleccionada3: null,
      opcionSeleccionada4: null,
      opcionSeleccionada5: null,
      opcionSeleccionada6: null,
      opcionSeleccionada7: null,
      opcionSeleccionada8: null,
      opcionSeleccionada9: null,
      opcionSeleccionada10: null,
      opcionSeleccionada11: null,
      opcionSeleccionada12: null,
      opcionSeleccionada13: null,
      opcionSeleccionada14: null,
      opcionSeleccionada15: null,
      opcionSeleccionada16: null,
      opcionSeleccionada17: null,
      opcionSeleccionada18: null,
      opcionSeleccionada19: null,
      opcionSeleccionada20: null,
      opcionSeleccionada21: null,
      opcionSeleccionada22: null,
      opcionSeleccionada23: null,
      respuestasCorrectas: [
        1, 1, 3, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 3, 4, 1, 2, 4, 3, 3, 2, 3,
      ],
      options: [
        { value: null, text: "Seleccione" },
        {
          value: "1",
          text: "Riesgos por comportamientos humanos.",
        },
        {
          value: "2",
          text: "Riesgos por estados del vehículo",
        },
        {
          value: "3",
          text: "Riesgos por la infraestructura",
        },
        {
          value: "4",
          text: "Riesgos por condiciones metrológicas",
        },
      ],
    };
  },
  methods: {
    comprobar1: function () {
      let errores = 0;
      let faltantes = 0;
      let inputs = document.querySelectorAll(".inputs");
      let mensajeError = document.querySelector("#mensajeError");
      mensajeError.classList.add("d-none");

      inputs.forEach((element) => {
        if (element.value == "") {
          mensajeError.classList.remove("d-none");
          faltantes++;
        }
        console.log(faltantes);
      });

      if (faltantes != 0) {
        return;
      }

      for (let i = 0; i < inputs.length; i++) {
        if (inputs[i].value != this.respuestasCorrectas[i]) {
          errores++;
        }
      }

      this.imgURL = "";
      this.tituloResultado = "";
      this.descripcionResultado = "";
      if (errores != 0) {
        this.imgURL = "recursos/img/Incorrecto.png";
        this.tituloResultado = "Incorrecto";
        this.descripcionResultado = "Intenta de nuevo.";
      } else {
        this.imgURL = "recursos/img/Correcto.png";
        this.tituloResultado = "Correcto";
        this.descripcionResultado = "";
      }
      this.$root.$emit("bv::show::modal", "modal-resultadosActividades");
    },
    validaSelect: function (event) {
      let numSelect = event.target.id.split("_")[1];
      let opcionElejida = event.target.value;
      let resultado = document.querySelectorAll(".resultado_" + numSelect);
      resultado.forEach((element) => {
        element.classList.add("d-none");
      });
      if (this.respuestasCorrectas1[numSelect - 1] == opcionElejida) {
        let resultadoPos = document.querySelector(
          ".resultado_" + numSelect + "_pos"
        );
        resultadoPos.classList.remove("d-none");
      } else {
        let resultadoNeg = document.querySelector(
          ".resultado_" + numSelect + "_neg"
        );
        resultadoNeg.classList.remove("d-none");
      }

      event.target.style.pointerEvents = "none";
    },
  },
  components: {
    Modales,
  },
  mounted() {
    SwiperController(), (document.title = this.$route.meta.title);
  },
};
</script>