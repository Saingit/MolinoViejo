<template>
  <div>
    <div class="row row-cols-1 row-cols-md-2 p-5">
      <b-col cols="12" lg="12">
        <h2 class="text-center p-5">¡Quienes Somos!</h2>
        <p class="text-center">
          Esta sección se encuentra en proceso de actualización
        </p>
      </b-col>
     
    </div>
  </div>
</template>


<script>
// import ModalRed from "@/components/Modales";

export default {};
</script>
