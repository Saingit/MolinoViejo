<template>
<div>
  <div class="row row-cols-1 row-cols-md-2 p-5">
      <b-col cols="12" lg="12">
        <h2 class="text-center p-5">Planes</h2>
      </b-col>
      <div class="col mb-4">
        <div class="card">
          <img
            src="recursos/img/p-diasol.jpg"
            class="card-img-top"
            alt="Día de sol"
          />
          <div class="card-body">
            <h5 class="card-title text-center">DÍA DE SOL</h5>
            <p class="card-text">
              $ 60.000 por persona le incluye desayuno almuerzo y refrigerio,
              ingreso a la piscina. Nota: No se permite el ingreso de mascotas a
              la piscina y zona de comidas.
            </p>
          </div>
        </div>
      </div>
      <div class="col mb-4">
        <div class="card">
          <img
            src="recursos/img/pcampin.jpg"
            class="card-img-top"
            alt="CAMPING"
          />
          <div class="card-body">
            <h5 class="card-title text-center">CAMPING</h5>
            <p class="card-text">
              $ 25.000 sin alimentación por persona <br />
              $ 65.000 con alimentación por persona le incluye desayuno almuerzo
              y cena. <br />
              Nota: En los 2 planes deben de traer las carpas
            </p>
          </div>
        </div>
      </div>
      <div class="col mb-4">
        <div class="card">
          <img
            src="recursos/img/p-alojamiento.jpg"
            class="card-img-top"
            alt="PLAN ALOJAMIENTO"
          />
          <div class="card-body">
            <h5 class="card-title text-center">ALOJAMIENTO</h5>
            <p class="card-text">
              $ 145.000 por persona con alimentación, niños menores de 5 años son
              gratis sin alimentación y niños de 6 años hasta los 8 años $ 50000,
              sin alimentación solo alojamiento
            </p>
          </div>
        </div>
      </div>
    </div>
     <div class="row row-cols-1 row-cols-md-2 p-5 justify-content-center">
      <div class="col col-lg-4 mb-4">
        <div class="card">
          <img
            src="recursos/img/p-romantico.jpg"
            class="card-img-top"
            alt="PLAN ROMÁNTICO"
          />
          <div class="card-body">
            <h5 class="card-title text-center">PLAN ROMÁNTICO</h5>
            <p class="card-text">
              $ 360.000 por pareja
            </p>
          </div>
        </div>
      </div>
      <div class="col col-lg-4 mb-4">
        <div class="card">
          <img
            src="recursos/img/img-cumple-home.png"
            class="card-img-top"
            alt="CUMPLEAÑOS"
          />
          <div class="card-body">
            <h5 class="card-title text-center">CUMPLEAÑOS</h5>
            <p class="card-text">
              $ 360.000 por pareja
            </p>
          </div>
        </div>
      </div>
      <div class="col col-lg-3 mb-4">
        <div class="card">
          <img
            src="recursos/img/header-contacto1.png"
            class="card-img-top"
            alt="Contáctanos"
          />
          <div class="card-body">
            <img src="recursos/img/logo.jpeg" class="card-img-top" alt="Logo" />
          </div>
        </div>
      </div>
      <div class="col col-lg-11 mb-4">
        <div class="card">
          <div class="card-body">
            <h5>Nota:</h5>
            <p>
              -El ingreso a la piscina es de $:15000 por persona, solo los niños
              menores de 5 años son gratis <br />
              -El ingreso a los charcos y zonas verdes es de $:7000 por persona,
              solo los niños menores de 5 años son gratis
            </p>
          </div>
        </div>
      </div>
    </div>

</div>
 
   

</template>

<script>
export default {};
</script>