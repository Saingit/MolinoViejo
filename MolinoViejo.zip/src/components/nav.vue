<template>
  <b-container fluid class="m-0 p-0 bgnav">

       
          <b-row class="m-0 p-0 justify-content-center">
            <b-col cols="12" lg="2">
                <img src="recursos/img/logo.jpeg" class="img-fluid w-25 rounded border shadow mt-1 "
                  alt="Logo" />
            </b-col>
            <b-col cols="12" lg="8" class="text-center">
              <p class="text-white text-center py-3 ">Llámanos <i class="fa fa-phone"></i> (604) 5579961 - 315 331 48 20 - 315 381 49 65 +RNT -
                  50567 <a href="https://www.instagram.com/molinoviejo.centrorecreativo/" target="_blank" rel="noopener noreferrer" class="p-3"> <i class="fa fa-instagram"></i></a>
                  <a href="https://www.facebook.com/molinoviejocentrorecreativo" target="_blank" rel="noopener noreferrer" class="p-3"> <i class="fa fa-facebook"></i></a></p>
             
            </b-col>
           
          </b-row>
       
     
  </b-container>
</template>

<script>
export default {
  name: "Nav",
};
</script>